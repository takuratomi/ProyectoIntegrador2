-- consultas

-- cosnulta de usuarios
--select * from usuario;

select * from sopa;