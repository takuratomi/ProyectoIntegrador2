package co.edu.usbcali.logica;

import co.edu.usbcali.dto.SemanaDTO;

public interface IPedidoLogica {
	
	public void crearPedido(SemanaDTO semanaDTO) throws Exception;	
}
