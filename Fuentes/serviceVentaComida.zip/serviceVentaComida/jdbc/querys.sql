/*---- consultas     --- */
-- cosnulta de usuarios
--select * from usuario;

--select * from bebida;
--select nextVal('seq_sopa')
/*insert into bebida(id,nombre,estado) values(nextVal('seq_bebida'),'JUGO DE MANGO','A'),
(nextVal('seq_bebida'),'JUGO DE PIÑA','A'),
(nextVal('seq_bebida'),'JUGO DE MANZANA','I'); */
-- delete from bebida; -- delete


-- RESTABLESER SECUENTA
-- ALTER SEQUENCE [nombre del sequences] RESTART principio;


select * from principio;
