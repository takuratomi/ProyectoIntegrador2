package co.edu.usbcali.dao;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.edu.usbcali.modelo.Bebida;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
@Rollback(false)
public class TestBebidaDAO {
	
	private static final Logger log=LoggerFactory.getLogger(TestBebidaDAO.class);
	
	
	@Autowired
	private IBebidaDAO bebidaDAO;	
	
	private int bebidaId=1;
	private SimpleDateFormat d = new SimpleDateFormat("dd-MM-yy");
	private	Date fechaModifica = d.parse("31-04-2017");
	private Date fechaCreacion = d.parse("31-03-2017");


	@Test
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
	public void aTest() {
		assertNotNull(bebidaDAO);
		
		Bebida bebida = bebidaDAO.consultarPorId(bebidaId);
		assertNull("La bebiad ya existe", bebida);
		bebida.setDescripcion("Sin azucar");
		bebida.setNombre("Coca cola zero");
		bebida.setFechaModifica(fechaModifica);
		bebida.setFechaCreacion(fechaCreacion);
		
		bebidaDAO.crear(bebida);
		
	}
	
	@Test
	@Transactional(readOnly=true)
	public void bTest() {
		assertNotNull(bebidaDAO);
		
		Bebida bebida = bebidaDAO.consultarPorId(bebidaId);
		assertNotNull(bebida);
		
		log.info("Id:"+bebida.getId());
		log.info("Nombre:"+bebida.getNombre());
		
		
	}
	
	@Test
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
	public void cTest() {
		
		assertNotNull(bebidaDAO);
		
		Bebida bebida = bebidaDAO.consultarPorId(bebidaId);
		assertNull("La bebida ya existe", bebida);
		bebida.setDescripcion("Sin azucar");
		bebida.setNombre("Coca cola zero");
		bebida.setFechaModifica(fechaModifica);
		bebida.setFechaCreacion(fechaCreacion);
		
		bebidaDAO.modificar(bebida);
		
	}
	
	@Test
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED, rollbackFor=Exception.class)
	public void dTest() {
		
		assertNotNull(bebidaDAO);
		
		Bebida bebida = bebidaDAO.consultarPorId(bebidaId);
		assertNotNull("La bebida no existe", bebida);
		
		bebidaDAO.borrar(bebida);
		
	}
	

}
