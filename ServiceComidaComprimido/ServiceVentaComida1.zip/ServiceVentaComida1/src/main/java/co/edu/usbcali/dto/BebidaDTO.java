package co.edu.usbcali.dto;

import java.math.BigDecimal;
import java.util.Date;

public class BebidaDTO {
	
	private BigDecimal id;
	private String nombre;
	private String descripcion;
	private String usuarioCreacion;
	private Date fechaCreacion;
	private String usuarioModifica;
	private Date fechaModifica;
	
	private String codigoError;
	private String mensajeError;
	
	public BebidaDTO() {
		
	}
	
	public BebidaDTO(BigDecimal id, String nombre, String descripcion, String usuarioCreacion,
			Date fechaCreacion, String usuarioModifica,Date fechaModifica, String codigoError, String mensajeError) {
		
		super();
		this.id=id;
		this.nombre=nombre;
		this.descripcion=descripcion;
		this.usuarioCreacion=usuarioCreacion;
		this.fechaCreacion=fechaCreacion;
		this.usuarioModifica=usuarioModifica;
		this.fechaModifica=fechaModifica;
		this.codigoError=codigoError;
		this.mensajeError=mensajeError;
		
	}
	
	
	public BigDecimal getId() {
		return id;
	}
	public void setId(BigDecimal id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}
	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	public String getUsuarioModifica() {
		return usuarioModifica;
	}
	public void setUsuarioModifica(String usuarioModifica) {
		this.usuarioModifica = usuarioModifica;
	}
	public Date getFechaModifica() {
		return fechaModifica;
	}
	public void setFechaModifica(Date fechaModifica) {
		this.fechaModifica = fechaModifica;
	}

	public String getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}
	
	
}
